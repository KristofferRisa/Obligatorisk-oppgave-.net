﻿using System.Collections.Generic;

namespace Trafikkal.web.Models.TestViewModels
{
    public class QuestionsIndexViewModel
    {
        public List<Question> Questions { get; set; }
        public List<Quiz> Quizzes { get; set; }
    }
}
