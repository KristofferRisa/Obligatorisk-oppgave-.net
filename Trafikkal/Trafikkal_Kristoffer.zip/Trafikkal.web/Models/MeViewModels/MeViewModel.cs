﻿namespace Trafikkal.web.Models.MeViewModels
{
    public class MeViewModel
    {
        public Student Student { get; set; }
        public UserScore UserScore { get; set; }
    }
}
