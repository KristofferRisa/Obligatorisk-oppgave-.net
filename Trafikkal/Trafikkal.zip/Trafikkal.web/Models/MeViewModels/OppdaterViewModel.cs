﻿namespace Trafikkal.web.Models.MeViewModels
{
    public class OppdaterViewModel
    {
        public Student Student { get; set; }
        public string Email { get; set; }
    }
}
