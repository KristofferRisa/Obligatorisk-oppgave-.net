﻿namespace Trafikkal.web.Models.TestViewModels
{
    public class ResultViewModel
    {
        public UserScore UserScore { get; set; }
        public Quiz Quiz { get; set; }
        public string Tekst { get; set; }
        public bool Passed { get; set; }
    }
}